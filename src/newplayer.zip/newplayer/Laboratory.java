package newplayer;

import battlecode.common.RobotController;

public class Laboratory extends MyRobot {

    RobotController rc;

    Laboratory(RobotController rc){
        super(rc);
    }

    void play(){

    }

}

