package newplayer;

import battlecode.common.RobotController;

public class Sage extends MyRobot {

    RobotController rc;

    Sage(RobotController rc){
        super(rc);
    }

    void play(){

    }

}

